---
outline: deep
---

## Parameter List

| Short | Long | Type | Description |
| ------ | ------ | ---- | ---- |
| `-c`   | `--config` | `FILE` | Path to the configuration file, lowest priority |
| `-u`   | `--url` | `TEXT` | Provide the corresponding link based on the mode |
| `-p`   | `--path` | `TEXT` | Save location for works |
| `-f`   | `--folderize` | `BOOLEAN` | Whether to save works in separate folders |
| `-M`   | `--mode` | `ENUM` | Download mode |
| `-n`   | `--naming` | `TEXT` | Global file naming format for works |
| `-k`   | `--cookie` | `TEXT` | Login cookie |
| `-i`   | `--interval` | `TEXT` | Download date range |
| `-e`   | `--timeout` | `INTEGER` | Network request timeout |
| `-r`   | `--max_retries` | `INTEGER` | Maximum retry attempts for network timeout |
| `-x`   | `--max-connections` | `INTEGER` | Number of concurrent network connections |
| `-t`   | `--max-tasks` | `INTEGER` | Number of asynchronous tasks |
| `-o`   | `--max-counts` | `INTEGER` | Maximum number of works to download |
| `-s`   | `--page-counts` | `INTEGER` | Number of works retrieved per page |
| `-P`   | `--proxies` | `TEXT...` | Proxy servers |
|        | `--insecure` | `FLAG` | Disable TLS certificate verification |
|        | `--update-config` | `BOOLEAN` | Update configuration file |
|        | `--init-config` | `TEXT` | Initialize configuration file |
|        | `--auto-cookie` | `ENUM` | Automatically obtain cookies |
| `-h`   |               | `FLAG` | Display rich-text help |
|        | `--help`      | `FLAG` | Show help information and exit |

## Detailed Explanation

### `--config`

Specifies the path to the configuration file, with the lowest priority. The default **main configuration file** path is `f2/conf/app.yaml`. Supports **absolute** and **relative paths**.

If the file cannot be parsed, `F2` reports the line and column of the error; it also stops with an error if the top level is not a key-value mapping or the file has no settings for this app, exiting with code `1`. When the app's settings are missing, use `--init-config` to add the default settings to the file.

### `--url`

Provides the corresponding link based on the mode.

### `--path`

The save location for works. Defaults to `Download` in the current directory. Supports **absolute paths**, **relative paths** and paths starting with `~` for the home directory (such as `~/Downloads`).

::: tip :bulb: Tip
Tweets are saved in `<path>/twitter/<mode>/<user nickname>`. When a user changes their nickname, the next download of that user (in any mode) renames the folders of the old nickname in every download mode to the new one, so the downloaded tweets stay with them and tweets whose file names have not changed are not downloaded again; later changes are followed as well. If a folder with the new nickname already exists in a mode, both folders of that mode are left as they are and a message is logged until you merge them and delete the old folder.
:::

### `--folderize`

Determines whether works should be saved in separate folders. Default is `true`.

### `--mode`

Download modes:
- `one`: Single work
- `post`: Homepage works, including the pinned tweet and threads (replies to their own tweets)
- `like`: Liked works. Likes on X are only visible to their owner, so the link must be the profile of the account the `cookie` belongs to
- `bookmark`: Bookmarked (saved) works

### `--naming`

Global file naming format for works. Defaults to `{create}_{desc}`. Supported variables include: `{create}`, `{nickname}`, `{tweet_id}`, `{desc}`, `{uid}`. Supported separators: `_`, `-`.

- `{create}`: Work creation time
- `{nickname}`: User nickname
- `{tweet_id}`: Work ID
- `{desc}`: Work caption
- `{uid}`: User ID

::: tip :bulb: Tip
- `custom_fields` allows developers to define custom field mappings. See: [Global Formatting for Filenames 🟢](/guide/apps/twitter/overview#global-formatting-filenames-🟢).
- In file names, captions and nicknames keep punctuation, spaces and all scripts as they are; only characters that file systems do not allow (`\ / : * ? " < > |`) are replaced with similar full-width characters (for example `?` becomes `？`), and newlines and other control characters are turned into spaces or removed. Captions longer than 200 bytes are shortened in the middle, and so is any file name that would exceed 255 bytes with its suffix, so files can also be saved to a NAS or other file systems that limit names by bytes. On Windows, paths longer than 260 characters automatically use the long path form, so no system setting needs to be changed.
:::

### `--cookie`

Login `Cookie`. Most APIs require login to access data, so a logged-in `Cookie` is required.

::: details :link: How to obtain `Cookie`
![Console Cookie](https://github.com/user-attachments/assets/4523e8c7-f74e-4d5f-9da6-6bb3658f8b24)
:::

::: tip :bulb: Tip
- `Twitter` requests need an `X-Csrf-Token`. `F2` automatically uses the `ct0` value in the `cookie`, so copying the complete `cookie` is enough. The `X-Csrf-Token` in the [**F2 Configuration File**](/site-config#main-configuration-file) is only used when the `cookie` has no `ct0`.
- If unable to fetch data or facing restrictions, update the `Cookie` promptly.
- Only ASCII characters are allowed. Double-check before updating configurations.
:::

::: danger :bangbang: Warning :bangbang:
- **Never share your `Cookie` in public spaces like Discussions, Issues, or Discord. Remove sensitive information.**
- **Anyone with access to your `Cookie` can log into your account.**
- **If leaked, log out and re-login immediately.**
:::

### `--interval`

Download tweets published within a date range, in the format `Year-Month-Day|Year-Month-Day`. Both days are included, and dates are in Beijing time (UTC+8). For example: `2024-01-01|2024-06-30`; set `all` to download all tweets.

::: tip :bulb: Tip
- Tweets are filtered by their publish time, in every mode.
- In `post` mode, `F2` pages from the newest tweet and stops once it reaches tweets published before the start date. The earlier the range, the more pages it has to go through. Pinned tweets are not in chronological order: they are still downloaded when they fall within the range, and they do not affect when paging stops.
- `like` and `bookmark` are ordered by when a tweet was liked or bookmarked, not by when it was published, so `F2` goes through all pages and then filters them by the range.
- An invalid date format, or an end date earlier than the start date, is reported as an error before any request is made.
- When `--max-counts` is also set, it counts the tweets left after date filtering.
:::

### `--timeout`

Network request timeout. Default is `10` seconds.

### `--max_retries`

Maximum retry attempts for network timeout. Default is `5` retries.

### `--max-connections`

Number of concurrent network connections. Default is `10`.

### `--max-tasks`

Number of asynchronous tasks. Default is `5`.

### `--max-counts`

The maximum number of tweets to download in this run, counted across all pages; paging stops once it is reached. `None` or `0` means no limit. Default is `0`.

### `--page-counts`

The number of tweets requested from the API at a time. It only decides how many requests (pages) are made and does not limit how many tweets are downloaded in total. Not recommended to exceed `20`. Default is `20`.

::: tip :bulb: Tip
`--page-counts` is how many to ask for per page and `--max-counts` is how many to download in total; one does not replace the other. For example, `-s 5 -o 2` requests 5 tweets at a time and downloads at most 2. To limit the number of downloads, set `--max-counts`.
:::

### `--proxies`

Configures the proxy server, supporting up to two parameters for `http://` and `https://` protocols.

Example: `--proxies http://x.x.x.x https://x.x.x.x`.

> [!IMPORTANT] IMPORTANT ❗❗❗
> **If the proxy does not support HTTPS egress, use: `--proxies http://x.x.x.x http://x.x.x.x`.**

### `--insecure`

Disable `TLS` certificate verification. Use it only behind a trusted debugging proxy. The flag affects the current run only and is not written to the configuration file; set `verify: false` in `conf.yaml` to disable it permanently. See [TLS certificate verification](/en/site-config#tls-certificate-verification).

```bash
f2 x --insecure --proxies http 127.0.0.1:8888 ...
```

### `--update-config`

Updates the configuration file via `CLI` parameters. See: [Configuring Cookies](/en/site-config#configure-cookies).

### `--init-config`

Initializes the high-frequency configuration file. See: [Initialize Config File](/en/site-config#initialize-configuration-file).

### `--auto-cookie`

Automatically retrieves `cookie` from the browser. Ensure the selected browser is closed before using this command. Supported browsers:
- `chrome`
- `firefox`
- `edge`
- `opera`
- `opera_gx`
- `safari`
- `chromium`
- `brave`
- `vivaldi`
- `librewolf`

On success, the cookie is written to the configuration file (the custom file given with `-c`, if any) and `F2` exits without downloading; on failure, it prints the reason and exits with code `1`.

Cookies from the latest Chrome and Edge on Windows cannot be read automatically for now; see the [FAQ](/en/faq#auto-cookie-failed-unable-to-get-key-for-cookie-decryption) for workarounds.

User settings switching is not supported.

> [!IMPORTANT] IMPORTANT ❗❗❗
> - Due to a `Chromium` security update, `Cookie` encryption has been upgraded to `V20`. This has temporarily broken the `--auto-cookie` command for cookies issued after `August 15, 2024`.
> - Update `F2` to the latest version for a fix.
> - If you do not wish to upgrade, manually install the dependency fix from the PR below:[borisbabic/browser_cookie3#215](https://github.com/borisbabic/browser_cookie3/pull/215)
> - As of `2024/Dec/23`, the fix does not support the latest `Chromium` version. Use a different browser or downgrade to a version before `v128`.

::: details :link: Example: Manually update `Cookie`.
```shell [bash]
f2 x -k "your_cookie" -c your_config.yaml --update-config
```
:::
