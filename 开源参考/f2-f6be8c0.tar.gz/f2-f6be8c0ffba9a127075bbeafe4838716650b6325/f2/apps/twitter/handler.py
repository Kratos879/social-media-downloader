# path: f2/apps/twitter/handler.py

import asyncio
from pathlib import Path
from typing import Any, AsyncGenerator, Optional, Set, Tuple, Union

from f2.apps.twitter.crawler import TwitterCrawler
from f2.apps.twitter.db import AsyncUserDB
from f2.apps.twitter.dl import TwitterDownloader
from f2.apps.twitter.filter import (
    BookmarkTweetFilter,
    LikeTweetFilter,
    PostTweetFilter,
    TweetDetailFilter,
    UserProfileFilter,
)
from f2.apps.twitter.model import (
    BookmarkTweetEncode,
    LikeTweetEncode,
    PostTweetEncode,
    TweetDetailEncode,
    UserProfileEncode,
)
from f2.apps.twitter.utils import (
    TweetIdFetcher,
    UniqueIdFetcher,
    create_or_rename_user_folder,
)
from f2.cli.cli_console import RichConsoleManager
from f2.exceptions.api_exceptions import APIResponseError
from f2.exceptions.base import F2Error
from f2.i18n.translator import _
from f2.log.logger import logger
from f2.utils.core.decorators import get_mode_handlers, mode_handler
from f2.utils.core.run_report import record_notification
from f2.utils.file.path import is_user_folder_migrated
from f2.utils.time.timestamp import get_timestamp, parse_interval, timestamp_2_str

rich_console = RichConsoleManager().rich_console
rich_prompt = RichConsoleManager().rich_prompt


def _select_tweets(
    page: Any,
    remaining: Union[int, float],
    interval: Optional[Tuple[int, int]] = None,
    seen: Optional[Set[str]] = None,
) -> Tuple[Any, int, bool]:
    """
    按日期区间与剩余数量截取一页推文
    (Cut a page of tweets to the date range and the remaining count)

    接口不按 count 返回，一页的推文数可能超过剩余数量。主页推文按发布时间倒序排列
    （置顶推文除外），本页最后一条非置顶推文早于区间开始时，之后的页面都在区间之前；
    喜欢与收藏按点赞、收藏的时间排列，调用方不应据此停止翻页。主页的串推可能在相邻
    两页各出现一次，已经交出的推文不再保留。

    Args:
        page (Any): 一页推文的过滤器 (Filter of a page)
        remaining (Union[int, float]): 还可以保留的推文数 (Tweets still allowed)
        interval (Optional[Tuple[int, int]]): 发布时间区间，秒级时间戳，包含首尾
        seen (Optional[Set[str]]): 之前各页已经交出的推文 ID，保留的推文会加入其中

    Returns:
        Tuple[Any, int, bool]: (截取后的页面, 保留的推文数, 是否已经翻过区间开始)
    """
    tweet_ids = page.tweet_id or []
    timestamps = page.tweet_timestamp or []
    pinned = getattr(page, "tweet_pinned", None) or [False] * len(tweet_ids)
    seen = set() if seen is None else seen

    kept, total, last_regular = [], 0, None
    for tweet_id, timestamp, is_pinned in zip(tweet_ids, timestamps, pinned):
        if not tweet_id:
            continue
        total += 1
        if tweet_id not in seen and (
            interval is None
            or (timestamp is not None and interval[0] <= timestamp <= interval[1])
        ):
            kept.append(tweet_id)
        if timestamp is not None and not is_pinned:
            last_regular = timestamp

    if interval:
        logger.info(
            _("本页 {0} 条推文中有 {1} 条在日期区间内").format(total, len(kept))
        )
    if len(kept) > remaining:
        kept = kept[: int(remaining)]
    seen.update(kept)
    reached_start = (
        interval is not None and last_regular is not None and last_regular < interval[0]
    )
    if len(kept) == total:
        return page, total, reached_start
    return page._keep_tweets(kept), len(kept), reached_start


class TwitterHandler:

    def __init__(self, kwargs: Optional[dict] = None) -> None:
        kwargs = kwargs or {}
        self.kwargs = kwargs
        self.downloader = TwitterDownloader(kwargs)

    async def fetch_user_profile(
        self,
        uniqueId: str,
    ) -> UserProfileFilter:
        """
        用于获取指定用户的个人信息
        (Used to get personal info of specified users)

        Args:
            uniqueId: str: 用户ID (User ID)

        Return:
            user: UserProfileFilter: 用户信息过滤器 (User info filter)
        """

        async with TwitterCrawler(self.kwargs) as crawler:
            params = UserProfileEncode(screen_name=uniqueId)
            response = await crawler.fetch_user_profile(params)
            user = UserProfileFilter(response)
            if user.nickname is None:
                raise APIResponseError(
                    _("`fetch_user_profile`请求失败，请更换cookie或稍后再试")
                )
            return UserProfileFilter(response)

    async def get_or_add_user_data(
        self,
        kwargs: dict,
        uniqueId: str,
        db: AsyncUserDB,
    ) -> Path:
        """
        获取或创建用户数据同时创建用户目录
        (Get or create user data and create user directory)

        Args:
            kwargs (dict): 配置参数 (Conf parameters)
            uniqueId (str): 用户ID (User ID)
            db (AsyncUserDB): 用户数据库 (User database)

        Returns:
            user_path (Path): 用户目录路径 (User directory path)
        """

        # 尝试从数据库中获取用户数据
        local_user_data = await db.get_user_info(uniqueId)

        # 从服务器获取当前用户最新数据
        current_user_data = await self.fetch_user_profile(uniqueId)

        # 获取当前用户最新昵称
        current_nickname = current_user_data.nickname

        # 设置用户目录
        user_path = create_or_rename_user_folder(
            kwargs, local_user_data, current_nickname
        )

        # 如果用户不在数据库中，将其添加到数据库
        if not local_user_data:
            await db.add_user_info(**current_user_data._to_dict())
            logger.debug(_("用户：{0} 已添加到数据库").format(current_nickname))
        # 昵称变化且各下载模式的旧目录都已改名时，把数据库中的昵称改为新昵称，
        # 以后再改名时从新昵称开始处理；还有旧目录时保留旧昵称，下次运行继续处理
        elif is_user_folder_migrated(
            kwargs, "twitter", local_user_data.get("nickname"), current_nickname
        ):
            await db.update_user_info(
                uniqueId=uniqueId,
                nickname=current_nickname,
                nickname_raw=current_user_data.nickname_raw,
            )
            logger.debug(_("用户：{0} 的新名称已更新到数据库").format(current_nickname))

        return user_path

    @mode_handler("one")
    async def handle_one_tweet(self):
        """
        用于处理单个推文。
        (Used to process a single tweet.)

        Args:
            kwargs: dict: 参数字典 (Parameter dictionary)
        """

        tweet_id = await TweetIdFetcher.get_tweet_id(
            str(self.kwargs.get("url")), proxies=self.kwargs.get("proxies")
        )
        tweet_data = await self.fetch_one_tweet(tweet_id)

        async with AsyncUserDB("twitter_users.db") as db:
            user_path = await self.get_or_add_user_data(
                self.kwargs, tweet_data.user_unique_id, db
            )

        # async with AsynctweetDB("twitter_tweets.db") as db:
        #     await self.get_or_add_tweet_data(
        #         tweet_data._to_dict(), db, self.ignore_fields
        #     )

        # 创建下载任务
        await self.downloader.create_download_tasks(
            self.kwargs, tweet_data._to_dict(), user_path
        )

    async def fetch_one_tweet(
        self,
        tweet_id: str,
    ) -> TweetDetailFilter:
        """
        用于获取单个推文。

        Args:
            tweet_id: str: 推文ID

        Return:
            tweet: TweetDetailFilter: 单个推文数据过滤器
        """

        logger.info(_("开始爬取推文：{0}").format(tweet_id))
        async with TwitterCrawler(self.kwargs) as crawler:
            params = TweetDetailEncode(focalTweetId=tweet_id)
            response = await crawler.fetch_tweet_detail(params)
            tweet = TweetDetailFilter(response, tweet_id)

        logger.info(
            _("推文ID：{0} 文案：{1} 作者：{2} 阅读量：{3}").format(
                tweet.tweet_id,
                tweet.tweet_desc,
                tweet.nickname,
                tweet.tweet_views_count,
            )
        )

        record_notification(
            _("[Twitter] 单个推文下载"),
            _(
                "推文ID：{0}\n"
                "文案：{1}\n"
                "作者：{2}\n"
                "阅读量：{3}\n"
                "下载时间：{4}"
            ).format(
                tweet.tweet_id,
                (
                    tweet.tweet_desc_raw[:20] + "..."
                    if len(tweet.tweet_desc) > 20
                    else tweet.tweet_desc_raw
                ),
                tweet.nickname,
                tweet.tweet_views_count,
                timestamp_2_str(get_timestamp("sec")),
            ),
            group="Twitter",
        )

        return tweet

    @mode_handler("post")
    async def handle_post_tweet(self):
        """
        用于处理主页推文。
        (Used to process a post tweet.)

        Args:
            kwargs: dict: 参数字典 (Parameter dictionary)
        """

        max_cursor = self.kwargs.get("max_cursor", "")
        page_counts = self.kwargs.get("page_counts", 20)
        max_counts = self.kwargs.get("max_counts")

        uniqueID = await UniqueIdFetcher.get_unique_id(
            str(self.kwargs.get("url")), proxies=self.kwargs.get("proxies")
        )
        user = await self.fetch_user_profile(uniqueID)

        async with AsyncUserDB("twitter_users.db") as udb:
            user_path = await self.get_or_add_user_data(self.kwargs, uniqueID, udb)

        async for tweet_list in self.fetch_post_tweet(
            user.user_rest_id,
            page_counts,
            max_cursor,
            max_counts,
            interval=parse_interval(self.kwargs.get("interval")),
        ):
            # 创建下载任务
            await self.downloader.create_download_tasks(
                self.kwargs, tweet_list._to_list(), user_path
            )

    async def fetch_post_tweet(
        self,
        userId: str,
        page_counts: int = 20,
        max_cursor: str = "",
        max_counts: Optional[Union[int, float]] = None,
        interval: Optional[Tuple[int, int]] = None,
    ) -> AsyncGenerator[PostTweetFilter, Any]:
        """
        用于获取用户发布的推文。

        Args:
            userId: str: 用户ID
            page_counts: int: 每次请求的推文数量
            max_cursor: str: 游标
            max_counts: int: 最大推文数
            interval: Tuple[int, int]: 发布时间区间，秒级时间戳（开始, 结束），包含首尾，
                为 None 时不限制；翻到区间开始之前的推文时停止翻页

        Return:
            tweet: PostTweetFilter: 用户发布的推文数据过滤器
        """

        max_counts = max_counts or float("inf")
        tweets_collected = 0
        # 已经交出的推文，串推可能在相邻两页各出现一次
        seen: Set[str] = set()
        # 默认使用 userId：第一页就结束时，nickname_raw 也有值（#401）
        nickname_raw = userId

        logger.info(_("开始爬取用户：{0} 发布的推文").format(userId))

        while tweets_collected < max_counts:
            current_request_size = min(page_counts, max_counts - tweets_collected)

            logger.debug(
                _("最大数量：{0} 每次请求数量：{1}").format(
                    max_counts, current_request_size
                )
            )
            logger.info(
                _("开始爬取第 {0} 页").format("1" if max_cursor == "" else max_cursor)
            )

            async with TwitterCrawler(self.kwargs) as crawler:
                params = PostTweetEncode(
                    userId=userId, count=int(current_request_size), cursor=max_cursor
                )
                response = await crawler.fetch_post_tweet(params)
                tweet = PostTweetFilter(response)

            logger.debug(
                _("推文ID：{0} 文案：{1} 作者：{2}").format(
                    tweet.tweet_id, tweet.tweet_desc, tweet.nickname
                )
            )

            # 当cursorType值为Bottom且entryId长度为2时，表示已经爬取完所有的推文
            if tweet.cursorType == "Bottom" and len(tweet.entryId) == 2:
                logger.info(_("已处理完所有发布的推文"))
                break

            page, kept, reached_start = _select_tweets(
                tweet, max_counts - tweets_collected, interval, seen
            )
            yield page

            # 只在本页有推文时更新昵称，最后一页可能不包含任何推文
            if tweet.nickname_raw:
                nickname_raw = tweet.nickname_raw[0]

            # 更新已经处理的推文数量 (Update the number of videos processed)
            tweets_collected += kept
            max_cursor = tweet.max_cursor

            if reached_start:
                logger.info(_("已获取到日期区间开始之前的推文，停止翻页"))
                break

            # 已经达到最大数量时直接结束，此前还会再等待 timeout 秒
            if tweets_collected >= max_counts:
                break

            # 避免请求过于频繁
            logger.info(_("等待 {0} 秒后继续").format(self.kwargs.get("timeout", 5)))
            await asyncio.sleep(self.kwargs.get("timeout", 5))

        logger.info(_("爬取结束，共爬取 {0} 个推文").format(tweets_collected))

        record_notification(
            _("[Twitter] 主页推文下载"),
            _("用户：{0}\n" "推文数：{1}\n" "下载时间：{2}").format(
                nickname_raw,
                tweets_collected,
                timestamp_2_str(get_timestamp("sec")),
            ),
            group="Twitter",
        )

    @mode_handler("like")
    async def handle_like_tweet(self):
        """
        用于处理喜欢推文。
        (Used to process like tweets.)

        Args:
            kwargs: dict: 参数字典 (Parameter dictionary)
        """

        max_cursor = self.kwargs.get("max_cursor", "")
        page_counts = self.kwargs.get("page_counts", 20)
        max_counts = self.kwargs.get("max_counts")

        uniqueID = await UniqueIdFetcher.get_unique_id(
            str(self.kwargs.get("url")), proxies=self.kwargs.get("proxies")
        )
        user = await self.fetch_user_profile(uniqueID)

        async with AsyncUserDB("twitter_users.db") as udb:
            user_path = await self.get_or_add_user_data(self.kwargs, uniqueID, udb)

        async for tweet_list in self.fetch_like_tweet(
            user.user_rest_id,
            page_counts,
            max_cursor,
            max_counts,
            interval=parse_interval(self.kwargs.get("interval")),
        ):
            # 创建下载任务
            await self.downloader.create_download_tasks(
                self.kwargs, tweet_list._to_list(), user_path
            )

    async def fetch_like_tweet(
        self,
        userId: str,
        page_counts: int = 20,
        max_cursor: str = "",
        max_counts: Optional[Union[int, float]] = None,
        interval: Optional[Tuple[int, int]] = None,
    ) -> AsyncGenerator[LikeTweetFilter, Any]:
        """
        用于获取用户喜欢的推文。

        Args:
            userId: str: 用户ID
            page_counts: int: 每次请求的推文数量
            max_cursor: str: 游标
            max_counts: int: 最大推文数
            interval: Tuple[int, int]: 发布时间区间，秒级时间戳（开始, 结束），包含首尾，
                为 None 时不限制；喜欢按点赞时间排列，会翻完全部页面

        Return:
            like: LikeTweetFilter: 用户喜欢的推文数据过滤器
        """

        max_counts = max_counts or float("inf")
        tweets_collected = 0
        # 已经交出的推文，串推可能在相邻两页各出现一次
        seen: Set[str] = set()

        logger.info(_("开始爬取用户：{0} 喜欢的推文").format(userId))

        while tweets_collected < max_counts:
            current_request_size = min(page_counts, max_counts - tweets_collected)

            logger.debug(
                _("最大数量：{0} 每次请求数量：{1}").format(
                    max_counts, current_request_size
                )
            )
            logger.info(
                _("开始爬取第 {0} 页").format("1" if max_cursor == "" else max_cursor)
            )

            async with TwitterCrawler(self.kwargs) as crawler:
                params = LikeTweetEncode(
                    userId=userId, count=int(current_request_size), cursor=max_cursor
                )
                response = await crawler.fetch_like_tweet(params)
                like = LikeTweetFilter(response)

            logger.debug(
                _("推文ID：{0} 推文文案：{1} 作者：{2}").format(
                    like.tweet_id, like.tweet_desc, like.nickname
                )
            )
            # X 从 2024 年 6 月起不再公开喜欢列表，请求别人的喜欢时返回空数据
            if like.max_cursor is None:
                logger.error(
                    _(
                        "没有获取到喜欢的推文：X 的喜欢列表只对本人可见，"
                        "只能下载 cookie 所属账号自己喜欢的推文"
                    )
                )
                break

            # 当cursorType值为Bottom且entryId长度为2时，表示已经爬取完所有的推文
            if like.cursorType == "Bottom" and len(like.entryId) == 2:
                logger.info(_("已处理完所有喜欢的推文"))
                break

            page, kept, _reached_start = _select_tweets(
                like, max_counts - tweets_collected, interval, seen
            )
            yield page

            # 更新已经处理的推文数量 (Update the number of videos processed)
            tweets_collected += kept
            max_cursor = like.max_cursor

            # 已经达到最大数量时直接结束，此前还会再等待 timeout 秒
            if tweets_collected >= max_counts:
                break

            # 避免请求过于频繁
            logger.info(_("等待 {0} 秒后继续").format(self.kwargs.get("timeout", 5)))
            await asyncio.sleep(self.kwargs.get("timeout", 5))

        logger.info(_("爬取结束，共爬取 {0} 个推文").format(tweets_collected))

        record_notification(
            _("[Twitter] 喜欢推文下载"),
            _("用户ID：{0}\n" "推文数：{1}\n" "下载时间：{2}").format(
                userId,
                tweets_collected,
                timestamp_2_str(get_timestamp("sec")),
            ),
            group="Twitter",
        )

    @mode_handler("bookmark")
    async def handle_bookmark_tweet(self):
        """
        用于处理收藏推文。
        (Used to process bookmark tweets.)

        Args:
            kwargs: dict: 参数字典 (Parameter dictionary)
        """

        max_cursor = self.kwargs.get("max_cursor", "")
        page_counts = self.kwargs.get("page_counts", 20)
        max_counts = self.kwargs.get("max_counts")

        uniqueID = await UniqueIdFetcher.get_unique_id(
            str(self.kwargs.get("url")), proxies=self.kwargs.get("proxies")
        )

        async with AsyncUserDB("twitter_users.db") as udb:
            user_path = await self.get_or_add_user_data(self.kwargs, uniqueID, udb)

        async for tweet_list in self.fetch_bookmark_tweet(
            page_counts,
            max_cursor,
            max_counts,
            interval=parse_interval(self.kwargs.get("interval")),
        ):
            # 创建下载任务
            await self.downloader.create_download_tasks(
                self.kwargs, tweet_list._to_list(), user_path
            )

    async def fetch_bookmark_tweet(
        self,
        page_counts: int = 20,
        max_cursor: str = "",
        max_counts: Optional[Union[int, float]] = None,
        interval: Optional[Tuple[int, int]] = None,
    ) -> AsyncGenerator[BookmarkTweetFilter, Any]:
        """
        用于获取用户收藏的推文。

        Args:
            page_counts: int: 每次请求的推文数量
            max_cursor: str: 游标
            max_counts: int: 最大推文数
            interval: Tuple[int, int]: 发布时间区间，秒级时间戳（开始, 结束），包含首尾，
                为 None 时不限制；收藏按收藏时间排列，会翻完全部页面

        Return:
            bookmark: BookmarkTweetFilter: 用户收藏的推文数据过滤器

        Note:
            不需要传入用户ID，提供Cookie即可
        """

        max_counts = max_counts or float("inf")
        tweets_collected = 0
        # 已经交出的推文，串推可能在相邻两页各出现一次
        seen: Set[str] = set()

        logger.info(_("开始爬取收藏的推文"))

        while tweets_collected < max_counts:
            current_request_size = min(page_counts, max_counts - tweets_collected)

            logger.debug(
                _("最大数量：{0} 每次请求数量：{1}").format(
                    max_counts, current_request_size
                )
            )
            logger.info(
                _("开始爬取第 {0} 页").format("1" if max_cursor == "" else max_cursor)
            )

            async with TwitterCrawler(self.kwargs) as crawler:
                params = BookmarkTweetEncode(
                    count=int(current_request_size), cursor=max_cursor
                )
                response = await crawler.fetch_bookmark_tweet(params)
                bookmark = BookmarkTweetFilter(response)

            logger.debug(
                _("推文ID：{0} 推文文案：{1} 作者：{2}").format(
                    bookmark.tweet_id, bookmark.tweet_desc, bookmark.nickname
                )
            )

            if bookmark.max_cursor is None:
                logger.error(_("该用户没有收藏的推文"))
                break

            # 当cursorType值为Bottom且entryId长度为2时，表示已经爬取完所有的推文
            if bookmark.cursorType == "Bottom" and len(bookmark.entryId) == 2:
                logger.info(_("已处理完所有收藏的推文"))
                break

            page, kept, _reached_start = _select_tweets(
                bookmark, max_counts - tweets_collected, interval, seen
            )
            yield page

            # 更新已经处理的推文数量 (Update the number of videos processed)
            tweets_collected += kept
            max_cursor = bookmark.max_cursor

            # 已经达到最大数量时直接结束，此前还会再等待 timeout 秒
            if tweets_collected >= max_counts:
                break

            # 避免请求过于频繁
            logger.info(_("等待 {0} 秒后继续").format(self.kwargs.get("timeout", 5)))
            await asyncio.sleep(self.kwargs.get("timeout", 5))

        logger.info(_("爬取结束，共爬取 {0} 个推文").format(tweets_collected))

        record_notification(
            _("[Twitter] 收藏推文下载"),
            _("推文数：{0}\n" "下载时间：{1}").format(
                tweets_collected,
                timestamp_2_str(get_timestamp("sec")),
            ),
            group="Twitter",
        )


async def main(kwargs):
    mode = kwargs.get("mode")
    handlers = get_mode_handlers(__name__)
    if mode in handlers:
        handler = TwitterHandler(kwargs)
        try:
            await handlers[mode](handler)
        finally:
            # 此前下载器的客户端没有关闭，连接要等事件循环关闭后才被回收，
            # Windows 上退出时会报 Event loop is closed
            await handler.downloader.close()
    else:
        raise F2Error(_("不存在该模式: {0}").format(mode))
