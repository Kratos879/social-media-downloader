# path: f2/apps/__apps__.py

_douyin = ["douyin", "dy"]
_tiktok = ["tiktok", "tk"]
_weibo = ["weibo", "wb"]
_youtube = ["youtube", "ytb"]
_instagram = ["instagram", "ig"]
_twitter = ["twitter", "x"]
_bilibili = ["bilibili", "bili"]
_twitch = ["twitch", "tv"]
_neteasy_music = ["neteasy_music", "ntm"]
_little_red_book = ["little_red_book", "lrb"]
_bark = ["bark", "bk"]

__all__ = [
    "_douyin",
    "_tiktok",
    "_weibo",
    "_youtube",
    "_instagram",
    "_twitter",
    "_bilibili",
    "_twitch",
    "_neteasy_music",
    "_little_red_book",
    "_bark",
]
